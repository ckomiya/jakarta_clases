package pe.jakarta.lp1.app_crud.faces.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

//@Entity
//@Table(name = "INFORMACION_LOGIN")
public class Login implements Serializable {

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "INFORMACION_LOGIN_ID")
//	private int informacionLoginId;
//
//	@OneToOne
//	@JoinColumn(name = "CLIENTE_ID", referencedColumnName = "CLIENTE_ID")
//	private Cliente cliente;
//
//	@Column(name = "NOMBRE_LOGIN")
//	private String usuario;
//
//	@Column(name = "CONTRASENA")
//	private String clave;
//
//	public int getInformacionLoginId() {
//		return informacionLoginId;
//	}
//
//	public void setInformacionLoginId(int informacionLoginId) {
//		this.informacionLoginId = informacionLoginId;
//	}
//
//	public Cliente getCliente() {
//		return cliente;
//	}
//
//	public void setCliente(Cliente cliente) {
//		this.cliente = cliente;
//	}
//
//	public String getUsuario() {
//		return usuario;
//	}
//
//	public void setUsuario(String usuario) {
//		this.usuario = usuario;
//	}
//
//	public String getClave() {
//		return clave;
//	}
//
//	public void setClave(String clave) {
//		this.clave = clave;
//	}

	
	
}
