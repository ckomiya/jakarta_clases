package pe.jakarta.lp1.app_crud.faces.entity;

public class TipoDireccion {

}
